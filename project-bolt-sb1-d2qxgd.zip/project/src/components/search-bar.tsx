import React from 'react';
import { Search, MapPin } from 'lucide-react';
import { Button } from './ui/button';

export function SearchBar() {
  return (
    <div className="flex w-full max-w-4xl items-center gap-2 rounded-lg bg-white p-2 shadow-lg">
      <div className="flex flex-1 items-center gap-2 border-r px-4">
        <Search className="h-5 w-5 text-gray-400" />
        <input
          type="text"
          placeholder="Rechercher une expérience..."
          className="w-full border-none bg-transparent text-gray-900 placeholder-gray-400 focus:outline-none"
        />
      </div>
      <div className="flex flex-1 items-center gap-2 px-4">
        <MapPin className="h-5 w-5 text-gray-400" />
        <input
          type="text"
          placeholder="Où ?"
          className="w-full border-none bg-transparent text-gray-900 placeholder-gray-400 focus:outline-none"
        />
      </div>
      <Button className="px-6">Rechercher</Button>
    </div>
  );
}