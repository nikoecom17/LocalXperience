import React from 'react';
import { Experience } from '@/types/experience';
import { formatPrice } from '@/lib/utils';
import { Star, Clock, Users } from 'lucide-react';

interface ExperienceCardProps {
  experience: Experience;
}

export function ExperienceCard({ experience }: ExperienceCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-lg">
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={experience.images[0]}
          alt={experience.title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm font-medium text-blue-600">{experience.category}</span>
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium">{experience.rating}</span>
            <span className="text-sm text-gray-500">({experience.reviewCount})</span>
          </div>
        </div>
        <h3 className="mb-2 text-lg font-semibold text-gray-900">{experience.title}</h3>
        <div className="mb-3 flex items-center gap-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{experience.duration} min</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>Max {experience.maxParticipants}</span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              src={experience.hostImage}
              alt={experience.hostName}
              className="h-8 w-8 rounded-full object-cover"
            />
            <span className="text-sm text-gray-600">Par {experience.hostName}</span>
          </div>
          <span className="text-lg font-semibold text-gray-900">
            {formatPrice(experience.price)}
          </span>
        </div>
      </div>
    </div>
  );
}