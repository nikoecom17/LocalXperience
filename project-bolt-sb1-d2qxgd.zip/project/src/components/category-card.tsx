import React from 'react';
import { Category } from '@/types/experience';
import { cn } from '@/lib/utils';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <div className="group cursor-pointer rounded-xl bg-white p-6 shadow-md transition-all hover:shadow-lg">
      <div className={cn(
        "mb-4 flex h-16 w-16 items-center justify-center rounded-full",
        "bg-blue-100 text-blue-600 transition-colors group-hover:bg-blue-600 group-hover:text-white"
      )}>
        <img src={category.icon} alt={category.name} className="h-8 w-8" />
      </div>
      <h3 className="mb-2 text-lg font-semibold text-gray-900">{category.name}</h3>
      <p className="text-sm text-gray-600">{category.description}</p>
    </div>
  );
}