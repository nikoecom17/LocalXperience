export interface Experience {
  id: string;
  title: string;
  description: string;
  price: number;
  duration: number; // in minutes
  location: {
    city: string;
    address: string;
    coordinates: {
      lat: number;
      lng: number;
    };
  };
  category: string;
  images: string[];
  hostName: string;
  hostImage: string;
  rating: number;
  reviewCount: number;
  maxParticipants: number;
}

export type Category = {
  id: string;
  name: string;
  icon: string;
  description: string;
};