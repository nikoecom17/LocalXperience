import { Category } from '@/types/experience';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Cuisine',
    icon: 'https://api.iconify.design/lucide:utensils.svg',
    description: 'Ateliers de cuisine et cours de pâtisserie'
  },
  {
    id: '2',
    name: 'Art & Culture',
    icon: 'https://api.iconify.design/lucide:palette.svg',
    description: 'Découvrez l\'art local et la culture'
  },
  {
    id: '3',
    name: 'Sport & Aventure',
    icon: 'https://api.iconify.design/lucide:mountain.svg',
    description: 'Activités sportives et aventures en plein air'
  },
  {
    id: '4',
    name: 'Bien-être',
    icon: 'https://api.iconify.design/lucide:heart.svg',
    description: 'Yoga, méditation et soins'
  }
];