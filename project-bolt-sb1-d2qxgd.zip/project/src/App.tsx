import React from 'react';
import { SearchBar } from './components/search-bar';
import { ExperienceCard } from './components/experience-card';
import { CategoryCard } from './components/category-card';
import { Navbar } from './components/navbar';
import { categories } from './data/categories';

const sampleExperience = {
  id: '1',
  title: 'Atelier de Cuisine Française Traditionnelle',
  description: 'Apprenez à cuisiner des plats français authentiques avec un chef expérimenté',
  price: 85,
  duration: 180,
  location: {
    city: 'Paris',
    address: '15 Rue de la Gastronomie',
    coordinates: { lat: 48.8566, lng: 2.3522 }
  },
  category: 'Cuisine',
  images: ['https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=2070'],
  hostName: 'Chef Jean Pierre',
  hostImage: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&q=80&w=768',
  rating: 4.8,
  reviewCount: 124,
  maxParticipants: 8
};

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative mt-16 bg-gradient-to-br from-blue-600 to-blue-800 px-4 py-24 text-white">
        <div className="mx-auto max-w-7xl">
          <h1 className="mb-6 text-center text-4xl font-bold leading-tight sm:text-5xl">
            Découvrez des expériences<br />locales uniques
          </h1>
          <p className="mx-auto mb-8 max-w-2xl text-center text-lg text-blue-100">
            Explorez des activités authentiques animées par des passionnés près de chez vous
          </p>
          <div className="flex justify-center">
            <SearchBar />
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="mx-auto max-w-7xl px-4 py-16">
        <h2 className="mb-8 text-2xl font-bold text-gray-900">Catégories populaires</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>

      {/* Featured Experiences */}
      <div className="mx-auto max-w-7xl px-4 py-16">
        <div className="mb-8 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Expériences à la une</h2>
          <button className="text-blue-600 hover:text-blue-700">Voir plus</button>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <ExperienceCard experience={sampleExperience} />
          <ExperienceCard experience={{...sampleExperience, 
            id: '2',
            title: 'Initiation à la Peinture Impressionniste',
            category: 'Art & Culture',
            price: 65,
            images: ['https://images.unsplash.com/photo-1579965342575-16428a7c8881?auto=format&fit=crop&q=80&w=2070']
          }} />
          <ExperienceCard experience={{...sampleExperience,
            id: '3',
            title: 'Randonnée et Yoga en Pleine Nature',
            category: 'Sport & Aventure',
            price: 45,
            images: ['https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=2070']
          }} />
        </div>
      </div>
    </div>
  );
}

export default App;